# MCAST IICT - LATEX DISSERTATION BASE TEMPLATE

## Table of Contents

* [Project Description](#Description)
* [Disclaimer](#Disclaimer)
* [Usage](#Usage)

## Description

LATEX base template for MCAST IICT.

## Disclaimer
The student acknowledges that it is solely his or her responsibility to verify that the final submitted layout complies with the latest MCAST dissertation guidelines. This is just a base template and it is the student's responsibility to update accordingly. Always discuss with  your mentor.

## Usage

Get the latest updates from the releases section. Upload zip on www.overleaf.com.
